package com.ISILSoftSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ISILSoftSpring.entity.Voto;

public interface VotoRepository extends JpaRepository<Voto, Integer>{

}
