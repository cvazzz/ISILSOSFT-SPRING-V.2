package com.ISILSoftSpring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ISILSoftSpring.entity.PartidoPolitico;

public interface PartidoPoliticoRepository extends JpaRepository<PartidoPolitico, Integer>{
	List<PartidoPolitico>  findAll();
	PartidoPolitico  findById(int codigo);
}