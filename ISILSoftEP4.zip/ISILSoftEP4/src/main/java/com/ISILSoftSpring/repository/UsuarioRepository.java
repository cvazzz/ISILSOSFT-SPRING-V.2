package com.ISILSoftSpring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ISILSoftSpring.entity.Usuario;


public interface UsuarioRepository  extends JpaRepository<Usuario, Integer>{

	Usuario findByCorreoAndPassword(String email, String contrasenha);
	Usuario findByCorreo(String email);
}
