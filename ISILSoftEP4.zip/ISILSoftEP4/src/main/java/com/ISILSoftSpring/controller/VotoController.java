package com.ISILSoftSpring.controller;

import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ISILSoftSpring.entity.Alumno;
import com.ISILSoftSpring.entity.PartidoPolitico;
import com.ISILSoftSpring.entity.Voto;
import com.ISILSoftSpring.repository.AlumnoRepository;
import com.ISILSoftSpring.repository.PartidoPoliticoRepository;
import com.ISILSoftSpring.repository.VotoRepository;



@Controller
@RequestMapping("/voto")
public class VotoController {
		@Autowired
		private AlumnoRepository alumnoRepository;
		
		@Autowired
		private PartidoPoliticoRepository  partidoPoliticoRepository;
		
		@Autowired
		private VotoRepository votoRepository;
		
		
	
		@RequestMapping(value="/grabarVoto",method=RequestMethod.POST)
		public String grabarVoto(HttpServletRequest request, Model model,@RequestParam("codigoAlumno")int codigoAlumno,Voto voto) throws AddressException, MessagingException {
			Alumno objAlumno = alumnoRepository.findById(codigoAlumno);
			List<PartidoPolitico> listaPartidos = partidoPoliticoRepository.findAll();
			PartidoPolitico objPartido = partidoPoliticoRepository.findById(voto.getPartidoPolitico().getCodigo());
			model.addAttribute("objAlumno",objAlumno);
			model.addAttribute("voto",voto);
			model.addAttribute("listaPartidos",listaPartidos);
			model.addAttribute("mensaje","Se registro el voto");
			voto.setAlumno(objAlumno);
			voto.setPartidoPolitico(objPartido);
			votoRepository.save(voto);
		
			return "registrarVoto";
		}
}
