package com.ISILSoftSpring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ISILSoftSpring.entity.Alumno;
import com.ISILSoftSpring.entity.PartidoPolitico;
import com.ISILSoftSpring.entity.Usuario;
import com.ISILSoftSpring.entity.Voto;
import com.ISILSoftSpring.repository.AlumnoRepository;
import com.ISILSoftSpring.repository.PartidoPoliticoRepository;
import com.ISILSoftSpring.repository.UsuarioRepository;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
	private PartidoPoliticoRepository  partidoPoliticoRepository;
	
	@Autowired 
	private AlumnoRepository  alumnoRepository;
	
	@PostMapping("/validarUsuario")
	public String validarUsuario(HttpServletRequest request, @RequestParam("correo") String correo, @RequestParam("password") String password, Model model) {
			Usuario objUsuario = usuarioRepository.findByCorreoAndPassword(correo, password);
			List<PartidoPolitico> listaPartidos = partidoPoliticoRepository.findAll();
			Voto voto = new Voto();
			
			if(objUsuario != null) {
				model.addAttribute("listaPartidos",listaPartidos);
				Alumno objAlumno = alumnoRepository.findById(objUsuario.getCodigo());
				model.addAttribute("objAlumno",objAlumno);
				model.addAttribute("voto",voto);
				model.addAttribute("mensaje",null);
				return "registrarVoto";
				
			}else {
				
				model.addAttribute("mensaje","El correo y/o password son incorrectos");
				return "index";
			}
		
		
	}

}
