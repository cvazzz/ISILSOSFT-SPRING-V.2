package com.ISILSoftSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaLibreriaWebSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaLibreriaWebSpringApplication.class, args);
	}

}
